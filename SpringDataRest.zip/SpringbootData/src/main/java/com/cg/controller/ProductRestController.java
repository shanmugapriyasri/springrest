package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Product;
import com.cg.dao.ProductRepository;

@RestController
@RequestMapping("/product")
public class ProductRestController {

	@Autowired
	ProductRepository productRepository;
	@Autowired
	Product product;
	//GET
	//http://localhost:8083/product/showproducts
	
	@GetMapping("/showproducts")
	public List<Product> getProducts(){
		List<Product> productList=productRepository.findAll();
		return productList;
	}
	
	//POST
	//http://localhost:8083/product/add/hp/laptop/35000
	@PostMapping("/add/{name}/{category}/{price}")
	public Product addProduct(@PathVariable String name,
			@PathVariable String category,@PathVariable Double price) {
		System.out.println("inserting");
		product.setName(name);
		product.setCategory(category);
		product.setPrice(price);
		Product instredproduct=productRepository.save(product);
		return instredproduct;
	}
	
	//http://localhost:8083/product/3001
	@GetMapping("/{id}")
	public Product getProductbyId(@PathVariable Integer id){
		Product product=productRepository.findById(id).get();
		return product;
	}
	
	//http://localhost:8083/product/byid?id=3001
		@GetMapping("/byid")
		public Product getProductbyName(@RequestParam Integer id){
			Product product=productRepository.findById(id).get();
			return product;
		}
		
		
		//http://localhost:8083/product/delete/3001
		@DeleteMapping("/delete/{id}")
		public String getdeletebyId(@PathVariable Integer id){
			productRepository.deleteById(id);
			return id +"deleted";
		}
		
		//Put
		//http://localhost:8083/product/update/3000/hp5/laptop/33333
		@PutMapping("/update/{id}/{name}/{category}/{price}")
		public Product updateProduct(@PathVariable Integer id,@PathVariable String name,
				@PathVariable String category,@PathVariable Double price) {
			product.setProductId(id);
			product.setName(name);
			product.setCategory(category);
			product.setPrice(price);
			Product updatedproduct=productRepository.save(product);
			return updatedproduct;
		}
		
}
